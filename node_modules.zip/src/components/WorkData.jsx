import gpt3 from '../assets/gpt3.png';
import todoproject from '../assets/todoproject.jpg';
const WorkData =[
    {
        imgsrc: gpt3,
        title: "GPT3",
        text:" This is a clone version of GPT3 only UI fully responsive",
        view:""
    },
    {
        imgsrc: todoproject,
        title: "TODO-LIST",
        text:" This is my first app ",
        view:""
    },
    {
        imgsrc: gpt3,
        title: "GPT3",
        text:" This is a clone version of GPT3 only UI fully responsive",
        view:""
    }
];
export default WorkData;
